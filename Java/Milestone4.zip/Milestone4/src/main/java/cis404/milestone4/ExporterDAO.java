package cis404.milestone4;
import java.sql.*;
import oracle.jdbc.OracleDriver;

public class ExporterDAO {
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String DB_USER = "student1";
    private static final String DB_PASSWORD = "pass";
    
	public Exporter checkLogin(String email, String password) throws SQLException, 
			ClassNotFoundException {
		DriverManager.registerDriver (new OracleDriver());
                Class.forName("oracle.jdbc.OracleDriver");
                Exporter exporter;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM EXPORTER WHERE EMAIL = ? and PASSWORD = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet result = statement.executeQuery();
            exporter = null;
            if (result.next()) {
                exporter = new Exporter();
                exporter.setId(result.getLong("EXP_ID"));
                exporter.setName(result.getString("COMPANY"));
                exporter.setEmail(email);
            }
        }

		return exporter;
	}
}