/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cis404.milestone4;

/**
 *
 * @author Lincoln Brown
 */
public class Exporter {
    private long id;
    private String name;
    private String email;
    private String password;
    private String phone;
    private String country;
    
    public long getId(){return this.id;}
    public String getName(){return this.name;}
    public String getEmail(){return this.email;}
    public String getPassword(){return this.password;}
    public String getPhone(){return this.phone;}
    public String getCountry(){return this.country;}
    
    public void setId(long id){this.id = id;}
    public void setName(String name){this.name = name;}
    public void setEmail(String email){this.email = email;}
    public void setPassword(String password){this.password = password;}
    public void setPhone(String phone){this.phone = phone;}
    public void setCountry(String country){this.country = country;}
    
}
