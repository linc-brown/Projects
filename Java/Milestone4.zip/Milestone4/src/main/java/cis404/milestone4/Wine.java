/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cis404.milestone4;

/**
 *
 * @author Lincoln Brown
 */
public class Wine {
    private long id;
    private String name;
    private String color;
    private String[] notes;
    
    public long getId(){return this.id;}
    public String getName(){return this.name;}
    public String getColor(){return this.color;}
    public String[] getNotes(){return this.notes;}
    
    public void setId(long id){this.id = id;}
    public void setName(String name){this.name = name;}
    public void setColor(String color){this.color = color;}
    public void setNotes(String[] notes){this.notes = notes;}

    //default constructor
    public Wine(){};
    
    //non-default constructor
    public Wine(final long id, final String name, final String color){
        this.id = id;
        this.name = name;
        this.color = color;
    }
    


}
