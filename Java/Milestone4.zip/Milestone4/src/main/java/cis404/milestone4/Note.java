/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cis404.milestone4;

/**
 *
 * @author elekt
 */
public class Note {
    private long noteId;
    private String noteName;
    
    public long getNoteId(){return this.noteId;}
    public String getNoteName(){return this.noteName;}
    
    public void setNoteId(long id){this.noteId = id;}
    public void setNoteName(String name){this.noteName = name;}
    
    public Note(){
        
    }
    public Note(long id, String name){
        this.noteId = id;
        this.noteName = name;
    }
}
