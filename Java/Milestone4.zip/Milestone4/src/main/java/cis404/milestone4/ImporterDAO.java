package cis404.milestone4;
import java.sql.*;
import oracle.jdbc.OracleDriver;

public class ImporterDAO {
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String DB_USER = "student1";
    private static final String DB_PASSWORD = "pass";
    
	public Importer checkLogin(String email, String password) throws SQLException, 
			ClassNotFoundException {
		DriverManager.registerDriver (new OracleDriver());
                Class.forName("oracle.jdbc.OracleDriver");
                Importer importer;
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT * FROM IMPORTER WHERE EMAIL = ? and PASSWORD = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, email);
            statement.setString(2, password);
            ResultSet result = statement.executeQuery();
            importer = null;
            if (result.next()) {
                importer = new Importer();
                importer.setName(result.getString("COMPANY"));
                importer.setEmail(email);
            }
        }

		return importer;
	}
}