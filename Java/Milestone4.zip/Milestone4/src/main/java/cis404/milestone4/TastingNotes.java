package cis404.milestone4;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author elekt
 */
public class TastingNotes {
    private long lineNo;
    private long noteId;
    private String noteName;
    private String[] notes;
    
    public long getLineNo(){return this.lineNo;}
    public long getNoteId(){return this.noteId;}
    public String getNoteName(){return this.noteName;}
    public String[] getNotes(){return this.notes;}
   
    public void setLineNo(long lineNo){this.lineNo = lineNo;}
    public void setNoteId(long noteId){this.noteId = noteId;}
    public void setNoteName(String noteName){this.noteName = noteName;}
    public void setNotes(String[] notes){this.notes = notes;}
    
    //default constructor method
    public TastingNotes(){}
    
    
}
