package cis404.milestone4;
import java.io.*;
import java.sql.SQLException;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ExporterLoginServlet")
public class ExporterLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public ExporterLoginServlet() {
		super();
	}
        @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		ExporterDAO exporterDAO = new ExporterDAO();
		try{
                Exporter exporter = exporterDAO.checkLogin(email, password);
                String destPage = "ExpLogin.jsp";
                if (exporter != null) {
                    HttpSession session = request.getSession();
                    session.setAttribute("exporter", exporter);
                    destPage = "ExpHome.jsp";
                } else {
                    System.err.println(email);
                    System.err.println(password);
                    String message = "Invalid email/password";
                    request.setAttribute("message", message);
                }
                RequestDispatcher dispatcher = request.getRequestDispatcher(destPage);
                dispatcher.forward(request, response);
                
                
                }catch(SQLException | ClassNotFoundException ex){
                    System.err.print(ex.getMessage());
                    throw new ServletException(ex);
                    
                }
        }
        
}