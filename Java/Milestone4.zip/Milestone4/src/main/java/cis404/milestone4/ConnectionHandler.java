/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cis404.milestone4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import oracle.jdbc.OracleDriver;

/**
 *
 * @author Lincoln Brown
 */
public class ConnectionHandler {
    private static final String DB_URL = "jdbc:oracle:thin:@localhost:1521:xe";
    private static final String DB_USER = "student1";
    private static final String DB_PASSWORD = "pass";
    private static final String QUERY_WINES = "SELECT * FROM WINE WHERE EXP_ID = ?";
    private static final String QUERY_WINE_NOTES = "SELECT NOTE_ID, NOTE_NAME FROM TASTING_NOTE "
            + "WHERE WINE_ID = ?";
     private static final String QUERY_ALL_NOTES = "SELECT NOTE_NAME FROM TASTING_NOTE ";
     private static final String QUERY_ALL_WINES = "SELECT * FROM WINE";
     private static final String INSERT_WINE = ""
            + "INSERT INTO WINE (WINE_ID, EXP_ID, NAME, COLOR) "
            + "VALUES(?, ?, ?, ?)";
     private static final String INSERT_TNOTE = ""
            + "INSERT INTO TASTING_NOTE (LINE_NO, WINE_ID, NOTE_ID, NOTE_NAME)"
            + "VALUES(?, ?, ?, ?)";
     
     private static final String INSERT_IMPORTER = ""
            + "insert into importer (imp_id, company, email, password, phone, country) "
            + "values(?, ?, ?, ?, ?, ?)";

     private static final String INSERT_EXPORTER = ""
            + "insert into exporter (exp_id, company, email, password, phone, country) "
            + "values(?, ?, ?, ?, ?, ?)";
     private static final String FIND_NOTEID = ""
             + "SELECT NOTE_ID FROM NOTE WHERE NOTE_NAME = ?";
     
    Statement stmt;
    Connection con;
    Wine[] wineArray;
    Note[] notes;
    String[] allNotes;
    ResultSet rs = null;
 
    
            //credit DB Connection methods to Alex Wangombe
        public void connectDB(){
        try{
            DriverManager.registerDriver (new OracleDriver());
            con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        }
        catch(SQLException e){
            System.err.println(e.getMessage());
        }
    };

    //close connection to database
    public void disconnectDB(){
        try{
            stmt.close();
            con.close();
        }
        catch(SQLException e){
            
        }
    }

    
    //used to return the results for a wine's tasting notes
       public Note[] returnNotes(long wineId){
             PreparedStatement prep = null;
            try{
                this.connectDB();
                con.setAutoCommit(false);
                prep = con.prepareStatement(QUERY_WINE_NOTES, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                prep.setLong(1, wineId); //set wineId to return the tasting notes
                rs = prep.executeQuery();
                //get number of rows and make a new string array to hold the value for each row
                if (rs.last()) {
                    int rows = rs.getRow();
                    rs.beforeFirst();
                    notes = new Note[rows];
                }
                int counter = 0;
                while(rs.next()){
                    notes[counter] = new Note(rs.getLong("NOTE_ID"), rs.getString("NOTE_NAME")); //put each tasting note in a string array "notes"
                    counter++;
                }
                con.commit();

            }
            catch(SQLException e)
            {
                 if(con != null){
                try{
                    System.err.print("ERRORTransaction is being rolled back\n");
                    System.err.print(e.getMessage());
                    con.rollback();
                }
                catch(SQLException ex){}
                }
            } finally {
            if(prep != null){
                try{
                    prep.close();
                    con.close();
                    con.setAutoCommit(true);
                }
                catch(SQLException exception){       
                }
            }   
        }
        return notes; //return the string array of tasting notes
    }   
    
    public long findNoteId(String noteName){
        this.connectDB();
        PreparedStatement ps = null;
        long noteId = 0;
        try{
            con.setAutoCommit(false);
            ps = con.prepareStatement(FIND_NOTEID, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ps.setString(1, noteName);
            ResultSet result = ps.executeQuery();
            if (result.last()) {
                int rows = result.getRow();
                result.beforeFirst();
            }
            int counter = 0;
            while(result.next()){
                noteId = result.getLong("NOTE_ID");
            }
     
        }catch(SQLException e){
            System.err.println(e.getMessage());
            if (con != null){
                try{
                    System.err.println("Transaction is being rolled back");
                    System.err.println(e.getMessage());
                    con.rollback();
                }catch(SQLException ex){     
                }
            }
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException exception) {
                }   
            }
        }
        return noteId;
        
    }         
       
       
             //used to return the results for a wine
    public Wine[] returnWine(long wineId){
        this.connectDB();
        PreparedStatement ps = null;
        try{
            con.setAutoCommit(false);
            ps = con.prepareStatement(QUERY_WINES, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ps.setLong(1, wineId);
            ResultSet result = ps.executeQuery();
            if (result.last()) {
                int rows = result.getRow();
                result.beforeFirst();
                wineArray = new Wine[rows];
            }
            int counter = 0;
            while(result.next()){
                wineArray[counter] = new Wine(result.getLong("WINE_ID"),result.getString("NAME"), 
                        result.getString("COLOR"));
                counter++;
            }
     
        }catch(SQLException e){
            System.err.println(e.getMessage());
            if (con != null){
                try{
                    System.err.println("Transaction is being rolled back");
                    System.err.println(e.getMessage());
                    con.rollback();
                }catch(SQLException ex){     
                }
            }
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException exception) {
                }   
            }
        }
        return wineArray;
        
    }      
    

                 //used to return the results for a wine
    public Wine[] returnAllWines(){
        this.connectDB();
        PreparedStatement ps = null;
        try{
            con.setAutoCommit(false);
            ps = con.prepareStatement(QUERY_ALL_WINES, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet result = ps.executeQuery();
            if (result.last()) {
                int rows = result.getRow();
                result.beforeFirst();
                wineArray = new Wine[rows];
            }
            int counter = 0;
            while(result.next()){
                wineArray[counter] = new Wine(result.getLong("WINE_ID"),result.getString("NAME"), 
                        result.getString("COLOR"));
                counter++;
            }
     
        }catch(SQLException e){
            System.err.println(e.getMessage());
            if (con != null){
                try{
                    System.err.println("Transaction is being rolled back");
                    System.err.println(e.getMessage());
                    con.rollback();
                }catch(SQLException ex){     
                }
            }
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException exception) {
                }   
            }
        }
        return wineArray;
        
    }
    
                     //used to return the results for a wine
    public Wine[] returnWineSelection(){
        this.connectDB();
        PreparedStatement ps = null;
        try{
            con.setAutoCommit(false);
            ps = con.prepareStatement(QUERY_ALL_WINES, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            ResultSet result = ps.executeQuery();
            if (result.last()) {
                int rows = result.getRow();
                result.beforeFirst();
                wineArray = new Wine[rows];
            }
            int counter = 0;
            while(result.next()){
                wineArray[counter] = new Wine(result.getLong("WINE_ID"),result.getString("NAME"), 
                        result.getString("COLOR"));
                counter++;
            }
     
        }catch(SQLException e){
            System.err.println(e.getMessage());
            if (con != null){
                try{
                    System.err.println("Transaction is being rolled back");
                    System.err.println(e.getMessage());
                    con.rollback();
                }catch(SQLException ex){     
                }
            }
        } finally {
            if (ps != null) {
                try {
                    ps.close();
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException exception) {
                }   
            }
        }
        return wineArray;
        
    }  
        
        public String printExpWine(long expId) {
        Wine[] array = this.returnWine(expId);
        StringBuilder out = new StringBuilder(""); 
        try {
            out.append("<table id=\"results\"> ");
            out.append("<tr>");
            out.append("<th>ID</th>");
            out.append("<th>Name</th>");
            out.append("<th>Color</th>");
            out.append("<th>Notes</th>");
            out.append("</tr>");
            StringBuilder wineNotes = new StringBuilder("");
            Long id = null;
            for (Wine wine : array) {
                id = wine.getId();
                notes = this.returnNotes(id);
                for(Note note: notes){
                    wineNotes.append(note.getNoteName());
                    wineNotes.append(" ");
                }
                String name = wine.getName();
                String color = wine.getColor();
                out.append("<tr>");
                out.append("<td>").append(id).append("</td>");
                out.append("<td>").append(name).append("</td>");
                out.append("<td>").append(color).append("</td>");
                out.append("<td>").append(wineNotes.toString()).append("</td>");
                out.append("</tr>");
                wineNotes = new StringBuilder("");
            }
            out.append("</table>");
        } catch (Exception e) {
        }        

        return out.toString();
    }
    
        
        
        
            public String printAllWines() {
        Wine[] array = this.returnAllWines();
        StringBuilder out = new StringBuilder(""); 
        try {
            out.append("<table id=\"results\"> ");
            out.append("<tr>");
            out.append("<th>ID</th>");
            out.append("<th>Name</th>");
            out.append("<th>Color</th>");
            out.append("<th>Notes</th>");
            out.append("</tr>");
            StringBuilder wineNotes = new StringBuilder("");
            Long id = null;
            for (Wine wine : array) {
                id = wine.getId();
                notes = this.returnNotes(id);
                for(Note note: notes){
                    wineNotes.append(note.getNoteName());
                    wineNotes.append(" ");
                }
                String name = wine.getName();
                String color = wine.getColor();
                out.append("<tr>");
                out.append("<td>").append(id).append("</td>");
                out.append("<td>").append(name).append("</td>");
                out.append("<td>").append(color).append("</td>");
                out.append("<td>").append(wineNotes.toString()).append("</td>");
                out.append("</tr>");
                wineNotes = new StringBuilder("");
            }
            out.append("</table>");
        } catch (Exception e) {
        }        

        return out.toString();
    }    
            
            
        public String[] returnAllNotes(){
             PreparedStatement prep = null;
            try{
                this.connectDB();
                con.setAutoCommit(false);
                prep = con.prepareStatement(QUERY_ALL_NOTES, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
                ResultSet rs = prep.executeQuery();
                //get number of rows and make a new string array to hold the value for each row
                if (rs.last()) {
                    int rows = rs.getRow();
                    rs.beforeFirst();
                    allNotes = new String[rows];
                }
                int counter = 0;
                while(rs.next()){
                    allNotes[counter] = rs.getString("NOTE_NAME"); //put each tasting note in a string array "allNotes"
                    counter++;
                }
                con.commit();

            }
            catch(SQLException e)
            {
                 if(con != null){
                try{
                    System.err.print("Transaction is being rolled back\n");
                    System.err.print(e.getMessage());
                    con.rollback();
                }
                catch(SQLException ex){}
                }
            } finally {
            if(prep != null){
                try{
                    prep.close();
                    con.close();
                    con.setAutoCommit(true);
                }
                catch(SQLException exception){       
                }
            }   
        }
        return allNotes; //return the string array of tasting notes
    }   
            
        public Wine InsertWine(long expId, String name, String color) {
        String idStmt = "SELECT WINE_ID.NEXTVAL FROM DUAL";
        PreparedStatement id = null; 
        long newId = 0;
        Wine newWine = null;
        try {
            Connection dbConn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                        id = dbConn.prepareStatement(idStmt);
            synchronized(this){
                ResultSet set = id.executeQuery();
                if(set.next()){newId = set.getLong(1);}
            }
            PreparedStatement stmt = dbConn.prepareStatement(INSERT_WINE);
            stmt.setLong(1, newId);
            stmt.setLong(2, expId);
            stmt.setString(3, name);
            stmt.setString(4, color);
            newWine = new Wine(newId, name, color);

            stmt.execute();
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        
        System.err.println("New record " + newId + " was created.");
        return newWine;
    }   
        
       public void InsertTNote(int lineNum, long wineId, long noteId, String noteName) {

        try {
            Connection dbConn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            PreparedStatement stmt = dbConn.prepareStatement(INSERT_TNOTE);
            stmt.setLong(1, lineNum);
            stmt.setLong(2, wineId);
            stmt.setLong(3, noteId);
            stmt.setString(4, noteName);
            

            stmt.execute();
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        System.err.println("New record " + " was created.");
    } 
    
       
    public void InsertImporter(String company, String email,
            String password, String phone, String country) {
        String idStmt = "SELECT IMP_ID.NEXTVAL FROM DUAL";
        PreparedStatement id = null;
        long newId = 0;
        try {
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            id = con.prepareStatement(idStmt);
            synchronized (this) {
                ResultSet set = id.executeQuery();
                if (set.next()) {
                    newId = set.getLong(1);
                }
            }
            PreparedStatement stmt = con.prepareStatement(INSERT_IMPORTER);
            stmt.setLong(1, newId);
            stmt.setString(2, company);
            stmt.setString(3, email);
            stmt.setString(4, password);
            stmt.setString(5, phone);
            stmt.setString(6, country);

            stmt.execute();
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        System.err.println("New record " + newId + " was created.");
    }

    public void InsertExporter(String company, String email,
            String password, String phone, String country) {
        String idStmt = "SELECT EXP_ID.NEXTVAL FROM DUAL";
        PreparedStatement id = null;
        long newId = 0;
        try {
            Connection con = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
            id = con.prepareStatement(idStmt);
            synchronized (this) {
                ResultSet set = id.executeQuery();
                if (set.next()) {
                    newId = set.getLong(1);
                }
            }
            PreparedStatement stmt = con.prepareStatement(INSERT_EXPORTER);
            stmt.setLong(1, newId);
            stmt.setString(2, company);
            stmt.setString(3, email);
            stmt.setString(4, password);
            stmt.setString(5, phone);
            stmt.setString(6, country);

            stmt.execute();
        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
        }
        System.err.println("New record " + newId + " was created.");
    }
       
}
